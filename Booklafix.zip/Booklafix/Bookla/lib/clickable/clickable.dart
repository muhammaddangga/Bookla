import 'package:flutter/material.dart';

class ClickableContainer extends StatefulWidget {
  final String imagePath;

  const ClickableContainer({
    Key? key,
    required this.imagePath,
  }) : super(key: key);

  @override
  ClickableContainerState createState() => ClickableContainerState();
}

class ClickableContainerState extends State<ClickableContainer> {
  bool _isClicked = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _isClicked = !_isClicked;
        });
      },
      child: Container(
        width: 200,
        height: 50,
        color: _isClicked ? Colors.blue : Colors.white,
        child: Center(
          child: _isClicked
              ? Image.asset(widget.imagePath,
                  fit: BoxFit
                      .cover) // Menampilkan gambar ketika _isClicked bernilai true
              : const Text(
                  'Lihat!',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  ),
                ),
        ),
      ),
    );
  }
}

// import 'package:flutter/material.dart';

// class ClickableContainer extends StatefulWidget {
//   const ClickableContainer({Key? key}) : super(key: key);

//   @override
//   // ignore: library_private_types_in_public_api
//   _ClickableContainerState createState() => _ClickableContainerState();
// }

// class _ClickableContainerState extends State<ClickableContainer> {
//   bool _isClicked = false;

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: () {
//         setState(() {
//           _isClicked = !_isClicked;
//         });
//       },
//       child: Container(
//         width: 200,
//         height: 50,
//         color: _isClicked ? Colors.blue : Colors.white,
//         child: Center(
//           child: Text(
//             _isClicked ? 'Clicked!' : 'Lihat!',
//             style: TextStyle(
//               fontSize: 18,
//               fontWeight: FontWeight.bold,
//               color: _isClicked ? Colors.white : Colors.black,
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }
