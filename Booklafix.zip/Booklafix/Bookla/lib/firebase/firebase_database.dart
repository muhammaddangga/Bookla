import 'package:firebase_database/firebase_database.dart';

final databaseReference = FirebaseDatabase.instance.ref();

void addUser(String userId, String name, String email, String role) {
  databaseReference.child("users").child(userId).set({
    'usherID'
        'name': name,
    'email': email,
    'role': role,
    // ... tambahkan field lainnya jika diperlukan
  });
}

void addVenue(String venueId, String ownerID, String name, String email,
    String description, String role, List<String> sports) {
  databaseReference.child("venues").child(venueId).set({
    'ownerID': ownerID,
    'name': name,
    'email': email,
    'description': description,
    'sports': sports,
    'role': role,
    // ... tambahkan field lainnya jika diperlukan
  });
}
