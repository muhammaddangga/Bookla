// import 'package:flutter/material.dart';
// import 'package:bookla/firebase/firebase_service.dart'; // Gantilah path ini dengan lokasi file firebase_service.dart yang sesungguhnya

// class SoccerScreen extends StatelessWidget {
//   const SoccerScreen({Key? key}) : super(key: key);

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Pilih Lapangan Sepak Bola'),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             // Judul halaman
//             const Text(
//               'Pilih Lapangan Olahraga',
//               style: TextStyle(
//                 fontSize: 24,
//                 fontWeight: FontWeight.bold,
//               ),
//             ),
//             const SizedBox(height: 10), // jarak antar widget
//             Expanded(
//               child: FutureBuilder<List<Map<String, dynamic>>>(
//                 future: getSports(),
//                 builder: (context, snapshot) {
//                   if (snapshot.connectionState == ConnectionState.done) {
//                     if (snapshot.hasError) {
//                       return Center(child: Text("Error: ${snapshot.error}"));
//                     }

//                     List<Map<String, dynamic>> sports = snapshot.data!;

//                     return ListView.builder(
//                       itemCount: sports.length,
//                       itemBuilder: (context, index) {
//                         return InkWell(
//                           onTap: () {
//                             // Aksi ketika item diklik
//                             showDialog(
//                               context: context,
//                               builder: (context) {
//                                 return AlertDialog(
//                                   title: Text(sports[index]['name']),
//                                   content: Text(sports[index]['description']),
//                                   actions: [
//                                     TextButton(
//                                       child: const Text('Tutup'),
//                                       onPressed: () {
//                                         Navigator.of(context).pop();
//                                       },
//                                     ),
//                                   ],
//                                 );
//                               },
//                             );
//                           },
//                           child: Container(
//                             margin: const EdgeInsets.only(bottom: 10),
//                             padding: const EdgeInsets.all(8),
//                             decoration: BoxDecoration(
//                               color: Colors.white,
//                               borderRadius: BorderRadius.circular(10),
//                               boxShadow: [
//                                 BoxShadow(
//                                   color: Colors.grey.withOpacity(0.1),
//                                   spreadRadius: 2,
//                                   blurRadius: 5,
//                                   offset: const Offset(0, 3),
//                                 ),
//                               ],
//                             ),
//                             child: Row(
//                               crossAxisAlignment: CrossAxisAlignment.start,
//                               children: [
//                                 Image.asset(
//                                   'assets/images/tampilanberanda.jpg',
//                                   width: 100,
//                                   height: 100,
//                                   fit: BoxFit.cover,
//                                 ),
//                                 const SizedBox(width: 10),
//                                 Expanded(
//                                   child: Column(
//                                     crossAxisAlignment:
//                                         CrossAxisAlignment.start,
//                                     children: [
//                                       Text(
//                                         sports[index]['name'],
//                                         style: const TextStyle(fontSize: 18),
//                                       ),
//                                       Row(
//                                         mainAxisAlignment:
//                                             MainAxisAlignment.spaceBetween,
//                                         children: [
//                                           Text(sports[index]['description']),
//                                           Text(
//                                               'Jarak: ${sports[index]['distance']}'),
//                                         ],
//                                       ),
//                                       Text(
//                                           'Rating: ${sports[index]['rating']}'),
//                                     ],
//                                   ),
//                                 ),
//                               ],
//                             ),
//                           ),
//                         );
//                       },
//                     );
//                   } else {
//                     return const Center(child: CircularProgressIndicator());
//                   }
//                 },
//               ),
//             ),
//             // Tombol untuk memilih tanggal dan waktu booking lapangan.
//             ElevatedButton(
//               onPressed: () {
//                 // Logika untuk booking lapangan sepak bola
//               },
//               child: const Text('Pilih Tanggal dan Waktu'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
