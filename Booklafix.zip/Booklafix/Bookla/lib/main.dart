// main.dart

// Mengabaikan warning tertentu untuk keseluruhan file (dalam hal ini library_prefixes)
// ignore_for_file: library_prefixes

// Mengimpor berbagai pustaka dan file yang dibutuhkan oleh aplikasi
// import 'package:bookla/Item_olahraga/soccer.dart';
// ignore: unused_import
// import 'package:bookla/property/tmp/akunvanue.dart';
import 'package:bookla/property/editPortofolioPage.dart';
import 'package:bookla/property/editProfilePage.dart';
import 'package:bookla/property/changePasswordPage.dart';
import 'package:bookla/property/photographerPage.dart';
import 'package:bookla/property/venuePage.dart';
import 'package:bookla/property/venuesPage.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'property/loginPage.dart';
import 'property/registerPage.dart';
import 'property/addVenuePage.dart';
import 'property/manageVenuePage.dart';
import 'property/editVenuePage.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
// import 'package:bookla/property/akun.dart'
//     as akunAlias; // Menggunakan alias untuk mencegah konflik nama
import 'package:bookla/property/homePage.dart'
    as homeAlias; // Sama seperti di atas
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';

// import 'property/tmp/vanuemanagementpage.dart';

// Fungsi main adalah titik masuk untuk aplikasi Flutter
void main() async {
  // Memastikan bahwa instance binding widget tersedia
  WidgetsFlutterBinding.ensureInitialized();

  // Menginisialisasi Firebase (penting untuk Firebase services)
  await Firebase.initializeApp();

  // Menjalankan aplikasi dengan widget MyApp sebagai root widget
  runApp(MyApp());
}

final _auth = FirebaseAuth.instance;

// MyApp adalah widget root untuk aplikasi Anda
// ignore: use_key_in_widget_constructors
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    debugPaintSizeEnabled = false;
    return ChangeNotifierProvider(
      create: (context) => homeAlias.UserRole(),
      child: MaterialApp(
        // Menghilangkan banner "debug" di pojok kanan atas
        debugShowCheckedModeBanner: false,
        initialRoute: _auth.currentUser != null ? '/home' : '/login',

        routes: {
          '/login': (context) => const LoginScreen(),
          '/register': (context) => const RegisterScreen(),
          '/home': (context) => const homeAlias.MyHomePage(),
          '/addVenue': (context) => const AddVenuePage(),
          '/editVenue': (context) => const EditVenuePage(),
          '/kelolaVenue': (context) => const KelolaVenuePage(),
          '/gantiPassword': (context) => const GantiPasswordPage(),
          '/editProfile': (context) => const EditProfilePage(),
          '/venues': (context) => const VenuesPage(),
          '/editPortofolio': (context) => const EditPortofolioPage(),
          '/photographer': (context) => const PhotographerPage(),
          '/venue': (context) => const VenuePage(),
        },
        builder: EasyLoading.init(),
      ),
    );
  }
}
