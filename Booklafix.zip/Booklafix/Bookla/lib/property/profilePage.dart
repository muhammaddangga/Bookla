// ignore_for_file: public_member_api_docs, sort_constructors_first
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'manageVenuePage.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

class BookingDataSource extends CalendarDataSource {
  BookingDataSource(List<Booking> source) {
    appointments = source;
  }

  @override
  DateTime getStartTime(int index) {
    return _getBookingData(index).from;
  }

  @override
  DateTime getEndTime(int index) {
    return _getBookingData(index).to;
  }

  @override
  String getSubject(int index) {
    return _getBookingData(index).eventName;
  }

  @override
  Color getColor(int index) {
    return _getBookingData(index).background;
  }

  @override
  bool isAllDay(int index) {
    return _getBookingData(index).isAllDay;
  }

  Booking _getBookingData(int index) {
    final dynamic booking = appointments![index];
    late final Booking BookingData;
    if (booking is Booking) {
      BookingData = booking;
    }

    return BookingData;
  }
}

class Booking {
  Booking(this.from, this.to);
  String eventName = "";
  DateTime from;
  DateTime to;
  Color background = const Color.fromARGB(255, 255, 0, 0);
  bool isAllDay = false;
}

class UserProfile extends StatefulWidget {
  final User user; // dari FirebaseAuth

  const UserProfile({
    Key? key,
    required this.user,
  }) : super(key: key);

  @override
  State<UserProfile> createState() => _UserProfileState();
}

class _UserProfileState extends State<UserProfile> {
  dynamic dbUser;
  List<dynamic> listPesanan = [];
  List<Booking> listBooking = [];

  @override
  void initState() {
    FirebaseFirestore.instance
        .collection('users')
        .where('uid', isEqualTo: widget.user.uid)
        .get()
        .then((QuerySnapshot querySnapshot) {
      final obj = querySnapshot.docs[0];
      if (obj.data() != null) {
        setState(() {
          dbUser = obj.data();
        });
      }
      if (dbUser["role"] == "user") {
        FirebaseFirestore.instance
            .collection('booking')
            .where('user_id', isEqualTo: widget.user.uid)
            .get()
            .then((QuerySnapshot querySnapshot) async {
          List<Map<String, dynamic>> data = [];
          for (QueryDocumentSnapshot element in querySnapshot.docs) {
            final elData = element.data() as Map<String, dynamic>;
            Map<String, dynamic> sub = {};
            if (elData["type"] == "fotografer") {
              final futureElData = await elData["fotografer"].get();
              sub = futureElData.data();
            } else if (elData["type"] == "venue") {
              final futureElData = await elData["venue"].get();
              sub = futureElData.data();
            }
            data.add({"id": element.id, "sub": sub, ...elData});
          }
          data.sort((a, b) =>
              b["waktuMulai"].toDate().compareTo(a["waktuMulai"].toDate()));
          setState(() {
            listPesanan = data;
          });
        });
      }
      if (dbUser["role"] == "fotografer") {
        FirebaseFirestore.instance
            .collection('fotografer')
            .where('userId', isEqualTo: widget.user.uid)
            .get()
            .then((QuerySnapshot querySnapshot) {
          final obj = querySnapshot.docs[0];
          FirebaseFirestore.instance
              .collection('booking')
              .where('fotografer',
                  isEqualTo: dbRef.collection("fotografer").doc(obj.id))
              .get()
              .then((QuerySnapshot querySnapshot) async {
            List<Map<String, dynamic>> data = [];
            List<Booking> tempListBooking = [];
            for (QueryDocumentSnapshot element in querySnapshot.docs) {
              final elData = element.data() as Map<String, dynamic>;
              Map<String, dynamic> sub = {};
              tempListBooking.add(Booking(elData["waktuMulai"].toDate(),
                  elData["waktuBerakhir"].toDate()));
              dynamic userData = await dbRef
                  .collection("users")
                  .where("uid", isEqualTo: elData["user_id"])
                  .get();
              sub = userData.docs[0].data();
              data.add({"id": element.id, "sub": sub, ...elData});
            }
            data.sort((a, b) =>
                b["waktuMulai"].toDate().compareTo(a["waktuMulai"].toDate()));
            setState(() {
              listPesanan = data;
              listBooking = tempListBooking;
            });
          });
        });
      }
      if (dbUser["role"] == "venue_owner") {
        FirebaseFirestore.instance
            .collection('venues')
            .where('user_id', isEqualTo: widget.user.uid)
            .get()
            .then((value) {
          final venueList = value.docs
              .map((e) => dbRef.collection("venues").doc(e.id))
              .toList();
          FirebaseFirestore.instance
              .collection('booking')
              .where('venue', whereIn: venueList)
              .get()
              .then((querySnapshot) async {
            List<Map<String, dynamic>> data = [];
            List<Booking> tempListBooking = [];
            for (QueryDocumentSnapshot dataElement in querySnapshot.docs) {
              final elData = dataElement.data() as Map<String, dynamic>;
              tempListBooking.add(Booking(elData["waktuMulai"].toDate(),
                  elData["waktuBerakhir"].toDate()));
              Map<String, dynamic> sub = {};
              dynamic userData = await dbRef
                  .collection("users")
                  .where("uid", isEqualTo: elData["user_id"])
                  .get();
              sub = userData.docs[0].data();
              data.add({
                "id": dataElement.id,
                "sub": sub,
                ...dataElement.data() as Map<String, dynamic>
              });
            }
            data.sort((a, b) =>
                b["waktuMulai"].toDate().compareTo(a["waktuMulai"].toDate()));
            setState(() {
              listPesanan = data;
              listBooking = tempListBooking;
            });
          });
        });
      }
    });

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Profile',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: ListView(
        children: [
          Image.network(
            dbUser != null && dbUser['profile'] != null
                ? dbUser!['profile']
                : "https://www.pngarts.com/files/10/Default-Profile-Picture-Transparent-Image.png",
            width: 50.0,
          ),
          ListTile(
            title: const Text('Name'),
            subtitle: Text(dbUser == null ? '' : dbUser!['name']),
          ),
          ListTile(
            title: const Text('Email'),
            subtitle: Text(dbUser == null ? '' : dbUser!['email']),
          ),
          ListTile(
            title: const Text('Role'),
            subtitle: Text(dbUser == null ? '' : dbUser!['role']),
          ),
          ListTile(
            title: const Text('Edit Profile'),
            onTap: () {
              Navigator.pushNamed(context, '/editProfile', arguments: dbUser);
            },
          ),
          ListTile(
            title: const Text('Change Password'),
            onTap: () {
              Navigator.pushNamed(context, '/gantiPassword');
            },
          ),
          dbUser != null && dbUser['role'] == 'fotografer'
              ? ListTile(
                  title: const Text('Edit Portofolio'),
                  onTap: () {
                    Navigator.pushNamed(context, '/editPortofolio',
                        arguments: {"userId": dbUser["uid"], "isFirst": false});
                  },
                )
              : Container(),
          dbUser != null && dbUser['role'] == 'venue_owner'
              ? ListTile(
                  title: const Text('Manage Venue'),
                  onTap: () {
                    Navigator.pushNamed(context, '/kelolaVenue',
                        arguments: KelolaVenueArguments(widget.user.uid));
                  },
                )
              : Container(),
          dbUser != null && dbUser!['role'] == 'venue_owner'
              ? ListTile(
                  title: const Text('Add Venue'),
                  onTap: () {
                    Navigator.pushNamed(context, '/addVenue',
                        arguments: {"isFirst": false});
                  },
                )
              : Container(),
          ListTile(
            title: const Text(
              'Logout',
              style: TextStyle(color: Color.fromARGB(255, 229, 10, 10)),
            ),
            onTap: () {
              showDialog(
                  context: context,
                  builder: (builder) {
                    return Dialog(
                        child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Text("Anda yakin ingin keluar ?"),
                          const SizedBox(height: 20),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              GestureDetector(
                                onTap: () {
                                  FirebaseAuth.instance.signOut();
                                  Navigator.pushNamed(context, '/login');
                                },
                                child: const Text("Ya"),
                              ),
                              const SizedBox(width: 20),
                              GestureDetector(
                                onTap: () => Navigator.of(context).pop(true),
                                child: const Text("Tidak"),
                              )
                            ],
                          )
                        ],
                      ),
                    ));
                  });
            },
          ),
          dbUser != null &&
                  (dbUser!['role'] == 'venue_owner' ||
                      dbUser!['role'] == 'fotografer')
              ? SfCalendar(
                  view: CalendarView.week,
                  dataSource: BookingDataSource(listBooking),
                )
              : Container(),
          dbUser != null && dbUser!['role'] == 'user'
              ? Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const Text(
                        "Order",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 20.0, fontWeight: FontWeight.bold),
                      ),
                      ...listPesanan
                          .map((e) => GestureDetector(
                              onTap: () {
                                if (!e["isRated"] &&
                                    DateTime.now()
                                        .isAfter(e['waktuBerakhir'].toDate())) {
                                  showDialog(
                                      context: context,
                                      builder: (builder) {
                                        return AlertDialog(
                                          content: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              IconButton(
                                                  onPressed: () {
                                                    _rate(
                                                        e["id"],
                                                        e["venue"] ??
                                                            e["fotografer"],
                                                        1);
                                                    Navigator.of(context)
                                                        .pop(true);
                                                  },
                                                  icon: const Icon(Icons.star)),
                                              IconButton(
                                                  onPressed: () {
                                                    _rate(
                                                        e["id"],
                                                        e["venue"] ??
                                                            e["fotografer"],
                                                        2);
                                                    Navigator.of(context)
                                                        .pop(true);
                                                  },
                                                  icon: const Icon(Icons.star)),
                                              IconButton(
                                                  onPressed: () {
                                                    _rate(
                                                        e["id"],
                                                        e["venue"] ??
                                                            e["fotografer"],
                                                        3);
                                                    Navigator.of(context)
                                                        .pop(true);
                                                  },
                                                  icon: const Icon(Icons.star)),
                                              IconButton(
                                                  onPressed: () {
                                                    _rate(
                                                        e["id"],
                                                        e["venue"] ??
                                                            e["fotografer"],
                                                        4);
                                                    Navigator.of(context)
                                                        .pop(true);
                                                  },
                                                  icon: const Icon(Icons.star)),
                                              IconButton(
                                                  onPressed: () {
                                                    _rate(
                                                        e["id"],
                                                        e["venue"] ??
                                                            e["fotografer"],
                                                        5);
                                                    Navigator.of(context)
                                                        .pop(true);
                                                  },
                                                  icon: const Icon(Icons.star)),
                                            ],
                                          ),
                                        );
                                      });
                                }
                              },
                              child: Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10.0),
                                    color: const Color(0xFF5572A9),
                                  ),
                                  margin: const EdgeInsets.only(top: 10.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Rent ${e['type'][0].toUpperCase()}${e['type'].substring(1)}",
                                            overflow: TextOverflow.clip,
                                            style: const TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Color(0xFFFFFFFF)),
                                          ),
                                          const SizedBox(height: 5),
                                          Text(
                                            // ignore: unnecessary_string_interpolations
                                            "${e['type'] == 'venue' ? 'Place' : 'Fotografer'}: ${e["type"] == "fotografer" ? e["sub"]["name"] : e["sub"]["nama"]}",
                                            style: const TextStyle(
                                                color: Color(0xFFFFFFFF)),
                                          ),
                                          const SizedBox(height: 5),
                                          Text(
                                            "Date: ${DateFormat('yyyy-MM-dd').format(e['waktuMulai'].toDate())}",
                                            style: const TextStyle(
                                                color: Color(0xFFFFFFFF)),
                                          ),
                                          const SizedBox(height: 5),
                                          Text(
                                            "Time: ${DateFormat('HH:mm').format(e['waktuMulai'].toDate())} - ${DateFormat('HH:mm').format(e['waktuBerakhir'].toDate())}",
                                            style: const TextStyle(
                                                color: Color(0xFFFFFFFF)),
                                          )
                                        ],
                                      ),
                                      DateTime.now().isAfter(
                                              e['waktuBerakhir'].toDate())
                                          ? Container(
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10.0),
                                                color: const Color.fromARGB(
                                                    255, 19, 220, 96),
                                              ),
                                              child: const Padding(
                                                  padding: EdgeInsets.all(5.0),
                                                  child: Text(
                                                    "Done",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color:
                                                            Color(0xFFFFFFFF)),
                                                  )),
                                            )
                                          : Container()
                                    ],
                                  ))))
                          .toList()
                    ],
                  ))
              : Container(),
          dbUser != null && dbUser!['role'] == 'fotografer'
              ? Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const Text(
                        "Order",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 20.0, fontWeight: FontWeight.bold),
                      ),
                      ...listPesanan
                          .map((e) => GestureDetector(
                              onTap: () {},
                              child: Container(
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(10.0),
                                    color: const Color(0xFF5572A9),
                                  ),
                                  margin: const EdgeInsets.only(top: 10.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          const Text(
                                            "Order",
                                            overflow: TextOverflow.clip,
                                            style: TextStyle(
                                                fontWeight: FontWeight.bold,
                                                color: Color(0xFFFFFFFF)),
                                          ),
                                          const SizedBox(height: 5),
                                          Text(
                                            "Order By: ${e['sub']['name']}",
                                            style: const TextStyle(
                                                color: Color(0xFFFFFFFF)),
                                          ),
                                          const SizedBox(height: 5),
                                          Text(
                                            "Date: ${DateFormat('yyyy-MM-dd').format(e['waktuMulai'].toDate())}",
                                            style: const TextStyle(
                                                color: Color(0xFFFFFFFF)),
                                          ),
                                          const SizedBox(height: 5),
                                          Text(
                                            "Time: ${DateFormat('HH:mm').format(e['waktuMulai'].toDate())} - ${DateFormat('HH:mm').format(e['waktuBerakhir'].toDate())}",
                                            style: const TextStyle(
                                                color: Color(0xFFFFFFFF)),
                                          )
                                        ],
                                      ),
                                      DateTime.now().isAfter(
                                              e['waktuBerakhir'].toDate())
                                          ? Container(
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10.0),
                                                color: const Color.fromARGB(
                                                    255, 19, 220, 96),
                                              ),
                                              child: const Padding(
                                                  padding: EdgeInsets.all(5.0),
                                                  child: Text(
                                                    "Done",
                                                    style: TextStyle(
                                                        fontWeight:
                                                            FontWeight.bold,
                                                        color:
                                                            Color(0xFFFFFFFF)),
                                                  )),
                                            )
                                          : Container()
                                    ],
                                  ))))
                          .toList()
                    ],
                  ))
              : Container(),
          dbUser != null && dbUser!['role'] == 'venue_owner'
              ? Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      const Text(
                        "Order",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: 20.0, fontWeight: FontWeight.bold),
                      ),
                      ...listPesanan
                          .map((e) => Container(
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.0),
                                color: const Color(0xFF5572A9),
                              ),
                              margin: const EdgeInsets.only(top: 10.0),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        "Order",
                                        overflow: TextOverflow.clip,
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xFFFFFFFF)),
                                      ),
                                      const SizedBox(height: 5),
                                      Text(
                                        "Order By: ${e['sub']['name']}",
                                        style: const TextStyle(
                                            color: Color(0xFFFFFFFF)),
                                      ),
                                      const SizedBox(height: 5),
                                      Text(
                                        "Date: ${DateFormat('yyyy-MM-dd').format(e['waktuMulai'].toDate())}",
                                        style: const TextStyle(
                                            color: Color(0xFFFFFFFF)),
                                      ),
                                      const SizedBox(height: 5),
                                      Text(
                                        "Time: ${DateFormat('HH:mm').format(e['waktuMulai'].toDate())} - ${DateFormat('HH:mm').format(e['waktuBerakhir'].toDate())}",
                                        style: const TextStyle(
                                            color: Color(0xFFFFFFFF)),
                                      )
                                    ],
                                  ),
                                  DateTime.now()
                                          .isAfter(e['waktuBerakhir'].toDate())
                                      ? Container(
                                          decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(10.0),
                                            color: const Color.fromARGB(
                                                255, 19, 220, 96),
                                          ),
                                          child: const Padding(
                                              padding: EdgeInsets.all(5.0),
                                              child: Text(
                                                "Done",
                                                style: TextStyle(
                                                    fontWeight: FontWeight.bold,
                                                    color: Color(0xFFFFFFFF)),
                                              )),
                                        )
                                      : Container()
                                ],
                              )))
                          .toList()
                    ],
                  ))
              : Container(),
        ],
      ),
    );
  }

  _rate(id, doc, rate) async {
    final rating = await doc.get();
    final ratingData = rating.data();
    try {
      await dbRef
          .collection("rates")
          .add({"user_id": widget.user.uid, "rate": rate, "doc": doc});
      await doc.update({
        "rating": [...ratingData["rating"], rate]
      });
      await dbRef.collection("booking").doc(id).update({"isRated": true});
    } on FirebaseException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString() ?? "An error occurred!")));
    }
  }
}
