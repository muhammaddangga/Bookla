import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_datetime_picker_plus/flutter_datetime_picker_plus.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

final storage = FirebaseStorage.instance;
final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class PhotographerPage extends StatefulWidget {
  const PhotographerPage({super.key});

  @override
  PhotographerPageState createState() => PhotographerPageState();
}

class PhotographerPageState extends State<PhotographerPage> {
  List<dynamic> listPortofolio = [];
  dynamic data;
  String userId = "";
  String nama = "";
  DateTime waktuMulai = DateTime.now();
  DateTime waktuBerakhir = DateTime.now();

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    setState(() {
      listPortofolio = args["portofolio"];
      nama = args["name"];
      userId = args["id"];
    });
    return Scaffold(
      appBar: AppBar(title: Text('Fotografer $nama')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            const Text(
              "Name",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
            ),
            const SizedBox(height: 5),
            Text(
              nama,
            ),
            const SizedBox(height: 15),
            const Text(
              "Portofolio",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
            ),
            const SizedBox(height: 5),
            SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                    children: listPortofolio
                        .map(
                          (e) => Container(
                            margin: const EdgeInsets.only(right: 10.0),
                            child: Image.network(
                              e,
                              width: 300,
                            ),
                          ),
                        )
                        .toList())),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              Column(children: [
                Container(
                  margin: const EdgeInsets.only(top: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      DatePicker.showDateTimePicker(
                        context,
                        minTime: DateTime(
                            DateTime.now().year,
                            DateTime.now().month,
                            DateTime.now().day,
                            DateTime.now().hour,
                            DateTime.now().minute),
                        maxTime: DateTime(
                          DateTime.now().year,
                          DateTime.now().month,
                          DateTime.now().day + 7,
                        ),
                        currentTime: waktuMulai,
                        onConfirm: (time) {
                          setState(() {
                            waktuMulai = time;
                          });
                        },
                      );
                    },
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            const Color(0xFF5572A9))),
                    child: const Text(
                      'Start Time',
                      style: TextStyle(color: Color(0xFFFFFFFF)),
                    ),
                  ),
                ),
                Text(
                  DateFormat('HH:mm').format(waktuMulai).toString(),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                )
              ]),
              Column(children: [
                Container(
                  margin: const EdgeInsets.only(top: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      DatePicker.showDateTimePicker(
                        context,
                        minTime: DateTime(
                            DateTime.now().year,
                            DateTime.now().month,
                            DateTime.now().day,
                            DateTime.now().hour,
                            DateTime.now().minute),
                        maxTime: DateTime(
                          DateTime.now().year,
                          DateTime.now().month,
                          DateTime.now().day + 7,
                        ),
                        currentTime: waktuBerakhir,
                        onConfirm: (time) {
                          setState(() {
                            waktuBerakhir = time;
                          });
                        },
                      );
                    },
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            const Color(0xFF5572A9))),
                    child: const Text(
                      'End Time',
                      style: TextStyle(color: Color(0xFFFFFFFF)),
                    ),
                  ),
                ),
                Text(
                  DateFormat('HH:mm').format(waktuBerakhir).toString(),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                )
              ])
            ]),
            Container(
                decoration: const BoxDecoration(
                    border: Border(bottom: BorderSide(width: 2.0))),
                child: Text(
                  "Total Price : Rp ${waktuBerakhir.difference(waktuMulai).inHours * 200000}",
                  style: const TextStyle(
                      fontSize: 20.0, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                )),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _book,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text(
                  'Book Now',
                  style: TextStyle(color: Color(0xFFFFFFFF)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  _book() async {
    final user = await dbRef
        .collection("users")
        .where("uid", isEqualTo: _auth.currentUser!.uid)
        .get();
    final userData = user.docs[0].data();
    if (userData["role"] != "user") {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Selain user tidak bisa booking !!")));
      return;
    }
    try {
      await dbRef.collection("booking").add({
        "type": "fotografer",
        "waktuMulai": waktuMulai,
        "waktuBerakhir": waktuBerakhir,
        "fotografer": dbRef.collection("fotografer").doc(userId),
        "user_id": _auth.currentUser!.uid,
        "isRated": false
      });
      Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString() ?? "An error occurred!")));
    }
  }
}
