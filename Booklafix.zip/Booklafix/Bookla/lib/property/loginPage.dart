// login.dart

// Mengimpor pustaka yang diperlukan
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart'; // Pustaka untuk autentikasi Firebase
import 'package:flutter/foundation.dart'; // Pustaka yang menyediakan fungsi dasar
import 'package:flutter/material.dart'; // Pustaka utama untuk UI Flutter

// Mendefinisikan widget LoginScreen yang bersifat stateful
class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  // Mengembalikan instance dari _LoginScreenState ketika LoginScreen dibuat
  LoginScreenState createState() => LoginScreenState();
}

class LoginScreenState extends State<LoginScreen> {
  // Menginisialisasi instance FirebaseAuth untuk autentikasi
  final _auth = FirebaseAuth.instance;

  // Controller untuk mengelola input email
  final _emailController = TextEditingController();

  // Controller untuk mengelola input password
  final _passwordController = TextEditingController();

  @override
  void initState() {
    super.initState();
    if (FirebaseAuth.instance.currentUser != null) {
      WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
        Navigator.pushNamedAndRemoveUntil(context, '/home', (route) => false);
      });
    }
  }

  // Fungsi untuk melakukan login dengan email dan password
  void _login() {
    if (_emailController.text == "" || _passwordController.text == "") {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("email atau password harus diisi!")));
      return;
    }
    _auth
        .signInWithEmailAndPassword(
      email: _emailController.text.trim(),
      password: _passwordController.text,
    )
        .then((user) async {
      final userCol = await FirebaseFirestore.instance
          .collection("users")
          .where("uid", isEqualTo: user.user?.uid)
          .get();
      final userData = userCol.docs[0].data();
      // Jika berhasil masuk, mengarahkan user ke halaman home
      if (userData["role"] == "venue_owner" && userData["isFirst"]) {
        Navigator.pushReplacementNamed(context, '/addVenue',
            arguments: {"isFirst": true});
        return;
      }
      if (userData["role"] == "fotografer" && userData["isFirst"]) {
        Navigator.pushReplacementNamed(context, '/editPortofolio',
            arguments: {"isFirst": true, "userId": user.user?.uid});
        return;
      }
      Navigator.pushReplacementNamed(context, '/home');
    }).catchError((error) {
      if (error.code == "INVALID_LOGIN_CREDENTIALS") {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("email atau password salah!")));
        return;
      }
      if (error is FirebaseAuthException) {
        // Menampilkan pesan kesalahan ke pengguna melalui SnackBar
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text(error.message!)));

        // Menangkap kesalahan jika ada dan mencetak pesan kesalahan jika aplikasi dalam mode debug
        if (kDebugMode) {
          print(error.message);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    // Membangun UI untuk halaman login
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login'),
        centerTitle: true,
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: <Widget>[
            // Field untuk input email
            Center(
              child: Image.asset(
                "assets/images/logo.jpg",
                width: 200.0,
                height: 200.0,
              ),
            ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),

            // Field untuk input password dengan teks tersembunyi
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),

            // Memberikan jarak antara field password dan tombol login
            const SizedBox(height: 20),

            // Tombol login yang ketika ditekan akan memanggil fungsi _login
            ElevatedButton(
              onPressed: _login,
              style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(
                      const Color(0xFF5572A9))),
              child: const Text(
                'Login',
                style: TextStyle(color: Color(0xFFFFFFFF)),
              ),
            ),

            // Tombol yang mengarahkan ke halaman registrasi jika user belum memiliki akun
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/register');
              },
              child: const Text('Don\'t have an account? Register'),
            ),
          ],
        ),
      ),
    );
  }
}
