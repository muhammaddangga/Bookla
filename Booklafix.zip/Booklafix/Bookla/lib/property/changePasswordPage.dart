import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

final _auth = FirebaseAuth.instance;

class GantiPasswordPage extends StatefulWidget {
  const GantiPasswordPage({super.key});

  @override
  GantiPasswordPageState createState() => GantiPasswordPageState();
}

class GantiPasswordPageState extends State<GantiPasswordPage> {
  final TextEditingController _passwordLama = TextEditingController();
  final TextEditingController _passwordBaru = TextEditingController();
  final TextEditingController _konfirmPassword = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Change Password')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              decoration: const InputDecoration(labelText: 'Last Password'),
              controller: _passwordLama,
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'New Password'),
              controller: _passwordBaru,
            ),
            TextField(
              decoration:
                  const InputDecoration(labelText: 'Confirm New Password'),
              controller: _konfirmPassword,
            ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _submitForm,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text(
                  'Change Password',
                  style: TextStyle(color: Color(0xFFFFFFFF)),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  _submitForm() async {
    if (_passwordBaru.text != _konfirmPassword.text) {
      return ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content:
              Text("New password with different password confirmation!!")));
    }
    try {
      final AuthCredential credential = EmailAuthProvider.credential(
          email: _auth.currentUser!.email!, password: _passwordLama.text);
      await _auth.currentUser?.reauthenticateWithCredential(credential);
      await _auth.currentUser?.updatePassword(_passwordBaru.text);
      Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(e.toString())));
    }
    // try {
    // } on FirebaseAuthException catch (e) {
    //   ScaffoldMessenger.of(context)
    //       .showSnackBar(SnackBar(content: Text(e.toString())));
    // }
  }
}
