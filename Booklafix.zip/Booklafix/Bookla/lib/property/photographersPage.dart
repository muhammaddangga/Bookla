import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class PhotographersPage extends StatefulWidget {
  const PhotographersPage({super.key});

  @override
  PhotographersPageState createState() => PhotographersPageState();
}

class PhotographersPageState extends State<PhotographersPage> {
  List<dynamic> _result = [];
  List<dynamic> _filteredResult = [];
  final TextEditingController _search = TextEditingController();
  @override
  void initState() {
    dbRef.collection("fotografer").get().then((snapshot) {
      setState(() {
        _result = snapshot.docs.map((e) {
          Map<String, dynamic> docData = e.data();
          int sum = 0;
          // ignore: unused_local_variable
          for (int num in docData["rating"]) {
            sum += num;
          }
          return {
            "id": e.id,
            "avgRating": sum / docData["rating"].length,
            ...docData
          };
        }).toList();
        _filteredResult = _result;
      });
    });
    super.initState();
  }

  // Fungsi untuk melakukan filter berdasarkan query pencarian.
  _filterSearchResults(String query) {
    List<Map<String, dynamic>> searchResult = [];
    if (query.isNotEmpty) {
      for (var item in _result) {
        if (item["name"]!.toLowerCase().contains(query.toLowerCase())) {
          searchResult.add(item);
        }
      }
      setState(() {
        _filteredResult = searchResult;
      });
    } else {
      setState(() {
        _filteredResult = _result;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            "Fotografer",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          centerTitle: true,
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(children: [
            TextField(
              controller: _search,
              onChanged: (value) {
                _filterSearchResults(value);
              },
              decoration: const InputDecoration(
                labelText: "Search",
                hintText: "Search",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(25.0)),
                ),
              ),
            ),
            ..._filteredResult
                .map((data) => GestureDetector(
                    onTap: () {
                      Navigator.pushNamed(context, '/photographer',
                          arguments: data);
                    },
                    child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          color: const Color(0xFF5572A9),
                        ),
                        margin: const EdgeInsets.only(top: 20.0),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: SizedBox.fromSize(
                                size: const Size.fromRadius(40),
                                child: Image.network(
                                    data["profile"] ??
                                        "https://www.pngarts.com/files/10/Default-Profile-Picture-Transparent-Image.png",
                                    fit: BoxFit.cover),
                              ),
                            ),
                            Expanded(
                                // padding: const EdgeInsets.only(left: 20.0),
                                child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Padding(
                                    padding: const EdgeInsets.only(left: 20.0),
                                    child: Column(
                                      children: [
                                        Text(
                                          data["name"],
                                          style: const TextStyle(
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFFFFFFFF)),
                                          overflow: TextOverflow.clip,
                                        ),
                                      ],
                                    )),
                                Row(children: [
                                  const Icon(
                                    Icons.star,
                                    color: Color.fromARGB(255, 255, 217, 0),
                                  ),
                                  Text(
                                    !data["avgRating"].isNaN
                                        ? data["avgRating"].toStringAsFixed(1)
                                        : "0",
                                    style: const TextStyle(
                                        color: Color(0xFFFFFFFF)),
                                  )
                                ])
                              ],
                            ))
                          ],
                        ))))
                .toList(),
          ]),
        ));
  }
}
