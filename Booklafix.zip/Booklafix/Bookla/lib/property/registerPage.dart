// ignore_for_file: use_build_context_synchronously

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

final _auth = FirebaseAuth.instance;
final dbRef = FirebaseFirestore.instance;

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  RegisterScreenState createState() => RegisterScreenState();
}

class RegisterScreenState extends State<RegisterScreen> {
  String?
      _role; // Nilai ini akan menentukan apakah user mendaftar sebagai "User" atau "Venue Owner"
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            DropdownButton<String>(
              hint: const Text("Select Role"),
              value: _role,
              items: const [
                DropdownMenuItem(value: "user", child: Text("User")),
                DropdownMenuItem(
                    value: "venue_owner", child: Text("Venue Owner")),
                DropdownMenuItem(
                    value: "fotografer", child: Text("Fotografer")),
              ],
              onChanged: (value) {
                setState(() {
                  _role = value;
                });
              },
            ),
            TextField(
              controller: _nameController,
              decoration: const InputDecoration(labelText: 'Name'),
            ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _passwordController,
              decoration: const InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _register,
              style: ButtonStyle(
                  backgroundColor: MaterialStateProperty.all<Color>(
                      const Color(0xFF5572A9))),
              child: const Text(
                'Register',
                style: TextStyle(color: Color(0xFFFFFFFF)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _register() async {
    EasyLoading.show(status: 'loading');
    if (_role == null ||
        _nameController.text.isEmpty ||
        _emailController.text.isEmpty ||
        _passwordController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Please fill all the fields!')));
      return;
    }

    try {
      // Mencoba membuat akun baru dengan email dan password yang diberikan
      await _auth.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );

      // Setelah berhasil mendaftar, Anda dapat memperbarui profil user
      User? currentUser = _auth.currentUser;
      await currentUser?.updateDisplayName(_nameController.text);

      // TODO: Anda mungkin juga ingin menyimpan data lain ke Firestore
      // misalnya role pengguna, dll.
      await dbRef.collection("users").add({
        'uid': currentUser!.uid,
        "name": _nameController.text,
        "email": _emailController.text,
        "role": _role,
        "isFirst": true
      });

      if (_role == "fotografer") {
        await dbRef.collection("fotografer").add({
          'userId': currentUser.uid,
          "name": _nameController.text,
          "portofolio": [],
          "rating": []
        });
      }

      // Mengarahkan pengguna ke halaman beranda atau sesuai dengan role mereka
      FirebaseAuth.instance.signOut().then((value) {
        EasyLoading.dismiss();
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      });
    } on FirebaseAuthException catch (e) {
      // Menangkap kesalahan jika ada dan menampilkan pesan kesalahan dengan SnackBar
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.message ?? "An error occurred!")));
    }
  }
}
