import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:io';

final storage = FirebaseStorage.instance;
final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class EditPortofolioPage extends StatefulWidget {
  const EditPortofolioPage({super.key});

  @override
  EditPortofolioPageState createState() => EditPortofolioPageState();
}

class EditPortofolioPageState extends State<EditPortofolioPage> {
  List<dynamic> listPortofolio = [];
  dynamic data;
  String? userId;
  bool isFirst = false;

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    FirebaseFirestore.instance
        .collection('fotografer')
        .where('userId', isEqualTo: args["userId"])
        .get()
        .then((QuerySnapshot querySnapshot) {
      final obj = querySnapshot.docs[0];
      if (obj.data() != null) {
        setState(() {
          data = obj.data();
          listPortofolio = data["portofolio"];
          userId = args["userId"];
          isFirst = args["isFirst"];
        });
      }
    });
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Portofolio'),
        automaticallyImplyLeading: !isFirst,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            ...listPortofolio
                .map(
                  (e) => Container(
                      margin: const EdgeInsets.only(top: 20.0),
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            GestureDetector(
                                onTap: () => _hapusGambar(e),
                                child: const Icon(
                                  Icons.close,
                                  size: 40.0,
                                )),
                            Image.network(e),
                          ])),
                )
                .toList(),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _pilihGambar,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text(
                  'Choose Image for Portofolio',
                  style: TextStyle(color: Color(0xFFFFFFFF)),
                ),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _submitPortofolio,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text(
                  'Submit Portofolio',
                  style: TextStyle(color: Color(0xFFFFFFFF)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  _hapusGambar(image) async {
    final removedPortofolio = listPortofolio;
    removedPortofolio.removeWhere((e) => e == image);
    await dbRef
        .collection("fotografer")
        .where("userId", isEqualTo: userId)
        .get()
        .then((value) async => await dbRef
            .collection("fotografer")
            .doc(value.docs[0].id)
            .update({"portofolio": removedPortofolio}));
    setState(() {
      listPortofolio.removeWhere((e) => e == image);
    });
  }

  _pilihGambar() async {
    File? _gambar;
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      _gambar = File(pickedFile.path);
      final ref = storage.ref().child("images/${_gambar.path.split('/').last}");
      final upload = await ref.putFile(_gambar);
      final uri = await ref.getDownloadURL();
      if (isFirst) {
        await dbRef
            .collection("users")
            .where("uid", isEqualTo: _auth.currentUser!.uid)
            .get()
            .then((value) async => await dbRef
                .collection("users")
                .doc(value.docs[0].id)
                .update({"isFirst": false}));
      }
      await dbRef
          .collection("fotografer")
          .where("userId", isEqualTo: userId)
          .get()
          .then((value) async => await dbRef
                  .collection("fotografer")
                  .doc(value.docs[0].id)
                  .update({
                "portofolio": [...listPortofolio, uri]
              }));
      setState(() {
        listPortofolio.add(uri);
      });
    }
  }

  _submitPortofolio() {
    Navigator.pushReplacementNamed(context, '/home');
  }
}
