import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';

final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;
final storage = FirebaseStorage.instance;

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});

  @override
  EditProfilePageState createState() => EditProfilePageState();
}

class EditProfilePageState extends State<EditProfilePage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _email = TextEditingController();
  String _oldEmail = "";
  String? _role;
  String? defaultRole;
  String userId = "";
  String gambar =
      "https://www.pngarts.com/files/10/Default-Profile-Picture-Transparent-Image.png";
  bool isUpdated = false;

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    if (!isUpdated) {
      setState(() {
        _name.text = args["name"];
        _email.text = args["email"];
        _oldEmail = args["email"];
        defaultRole = args["role"];
        userId = args["uid"];
        gambar = args["profile"] ??
            "https://www.pngarts.com/files/10/Default-Profile-Picture-Transparent-Image.png";
        isUpdated = true;
      });
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Profile')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            Image.network(
              gambar != ""
                  ? gambar
                  : "https://www.pngarts.com/files/10/Default-Profile-Picture-Transparent-Image.png",
              width: 100.0,
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0),
              child: ElevatedButton(
                onPressed: _pilihProfil,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text(
                  'Choose Profile Foto',
                  style: TextStyle(color: Color(0xFFFFFFFF)),
                ),
              ),
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Name'),
              controller: _name,
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Email'),
              controller: _email,
            ),
            DropdownButton(
              hint: const Text("Select Role"),
              value: _role,
              items: const [
                DropdownMenuItem(value: "user", child: Text("User")),
                DropdownMenuItem(
                    value: "venue_owner", child: Text("Venue Owner")),
                DropdownMenuItem(
                    value: "fotografer", child: Text("Fotografer")),
              ],
              onChanged: (value) {
                setState(() {
                  _role = value;
                });
              },
            ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _submitProfile,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text(
                  'Change Profile',
                  style: TextStyle(color: Color(0xFFFFFFFF)),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  _submitProfile() async {
    final fotografer = await dbRef
        .collection("fotografer")
        .where("userId", isEqualTo: userId)
        .get();
    if (fotografer.docs.isEmpty) {
      await dbRef.collection("fotografer").add({
        'userId': userId,
        "name": _name.text,
        "portofolio": [],
        "rating": []
      });
    }
    try {
      if (_oldEmail != _email.text) {
        await _auth.currentUser?.updateEmail(_email.text);
        await dbRef
            .collection("users")
            .where("uid", isEqualTo: userId)
            .get()
            .then((value) async =>
                await dbRef.collection("users").doc(value.docs[0].id).update({
                  "profile": gambar,
                  "name": _name.text,
                  "role": _role ?? defaultRole,
                  "email": _email.text
                }));
      } else {
        await dbRef
            .collection("users")
            .where("uid", isEqualTo: userId)
            .get()
            .then((value) async => await dbRef
                    .collection("users")
                    .doc(value.docs[0].id)
                    .update({
                  "profile": gambar,
                  "name": _name.text,
                  "role": _role ?? defaultRole
                }));
      }
      if (_role == "fotografer") {
        await dbRef
            .collection("fotografer")
            .where("userId", isEqualTo: userId)
            .get()
            .then((value) async => await dbRef
                .collection("fotografer")
                .doc(value.docs[0].id)
                .update({"profile": gambar, "name": _name.text}));
      }
      Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseException catch (e) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("An error occurred!")));
    }
  }

  _pilihProfil() async {
    File? _gambar;
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      _gambar = File(pickedFile.path);
      final ref = storage.ref().child("images/${_gambar.path.split('/').last}");
      final upload = await ref.putFile(_gambar);
      final uri = await ref.getDownloadURL();
      setState(() {
        gambar = uri;
      });
    }
  }
}
