import 'package:bookla/property/photographersPage.dart';
import 'package:bookla/property/profilePage.dart';
// import 'package:bookla/property/tmp/akunvanue.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:provider/provider.dart';

// Widget utama halaman Home.
class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  // ignore: library_private_types_in_public_api
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  // Index untuk menentukan halaman yang aktif saat ini.
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    if (FirebaseAuth.instance.currentUser == null) {
      WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
        Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
      });
    }
  }

  // Daftar halaman yang bisa ditampilkan.
  List<Widget> get _pages {
    var userRole = Provider.of<UserRole>(context, listen: false).role;
    var firebaseUser = FirebaseAuth
        .instance.currentUser; // Mendapatkan pengguna yang sedang masuk

    // Pastikan untuk mengecek apakah firebaseUser tidak null sebelum menggunakannya
    if (firebaseUser == null) {
      // Anda bisa menghandle kasus ketika pengguna belum masuk di sini,
      // mungkin dengan menampilkan pesan atau halaman lain
      return [const HomeScreen(), const SizedBox.shrink()]; // contoh sementara
    }

    return [
      const HomeScreen(),
      const PhotographersPage(),
      UserProfile(user: firebaseUser),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Menampilkan halaman yang sesuai dengan _currentIndex.
      body: FirebaseAuth.instance.currentUser == null
          ? const SizedBox.expand()
          : _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.camera_alt),
            label: 'Fotografer',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.account_circle),
            label: 'Akun',
          ),
        ],
        onTap: (index) {
          // Ketika item di bottom navigation bar ditekan, ubah _currentIndex.
          setState(() {
            _currentIndex = index;
          });
        },
      ),
    );
  }
}

// Halaman Akun.
// class AkunScreen extends StatelessWidget {
//   const AkunScreen({super.key});

//   @override
//   Widget build(BuildContext context) {
//     return const Center(child: Text('Halaman Akun'));
//   }
// }

class UserRole with ChangeNotifier {
  String? _role;

  String? get role => _role;

  set role(String? value) {
    _role = value;
    notifyListeners();
  }

  void fetchUserRole(User? user) {
    if (user != null) {
      FirebaseFirestore.instance
          .collection('users')
          .doc(user.uid)
          .get()
          .then((doc) {
        _role = doc.data()?['role'] ?? 'user';
        notifyListeners();
      });
    }
  }
}

// Halaman Home dengan fitur pencarian dan tampilan grid.
class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  HomeScreenState createState() => HomeScreenState();
}

class HomeScreenState extends State<HomeScreen> {
  String? userRole;
  final TextEditingController _searchController = TextEditingController();

  // Semua item yang ada.
  final List<Map<String, String>> _allItems = [
    {
      "name": "Soccer",
      "asset": "assets/icons/soccer-ball-svgrepo-com.svg",
      "jenis": "soccer"
    },
    {
      "name": "Basket",
      "asset": "assets/icons/sports_basketball_black_24dp.svg",
      "jenis": "basket"
    },
    {
      "name": "Volley",
      "asset": "assets/icons/sports_volleyball_black_24dp.svg",
      "jenis": "volley"
    },
    {
      "name": "Badminton",
      "asset": "assets/icons/badminton-svgrepo-com.svg",
      "jenis": "badminton"
    },
    {"name": "Futsal", "asset": "assets/icons/futsal.svg", "jenis": "futsal"}
  ];
  // Item yang ditampilkan berdasarkan pencarian.
  List<Map<String, String>> _filteredItems = [];

  @override
  // Membersihkan controller saat widget dihancurkan.
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();

    // Mengawasi perubahan status autentikasi pengguna
    FirebaseAuth.instance.authStateChanges().listen((User? user) {
      Provider.of<UserRole>(context, listen: false).fetchUserRole(user);
    });
    // Awalnya, semua item ditampilkan.
    _filteredItems = List.from(_allItems);
  }

  // Fungsi untuk melakukan filter berdasarkan query pencarian.
  _filterSearchResults(String query) {
    List<Map<String, String>> searchResult = [];
    if (query.isNotEmpty) {
      for (var item in _allItems) {
        if (item["name"]!.toLowerCase().contains(query.toLowerCase())) {
          searchResult.add(item);
        }
      }
      setState(() {
        _filteredItems = searchResult;
      });
    } else {
      setState(() {
        _filteredItems = _allItems;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'BOOKLA',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            // Search Bar
            TextField(
              onChanged: (value) {
                _filterSearchResults(value);
              },
              controller: _searchController,
              decoration: const InputDecoration(
                labelText: "Search Kategori",
                hintText: "Search Kategori",
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.all(Radius.circular(25.0)),
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Konten di bawah Search Bar.
            GridView.count(
              crossAxisCount: 3,
              physics: const NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              children: _filteredItems.map((itemData) {
                return InkWell(
                  onTap: () {
                    // Tambahkan logika untuk menangani klik item di sini
                    // Contoh: Navigasi ke halaman olahraga yang sesuai
                    Navigator.pushNamed(context, '/venues', arguments: {
                      "nama": itemData["name"]!,
                      "jenis": itemData["jenis"]!
                    });
                  },
                  child: Card(
                    color: const Color(0xFF5572A9),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        SvgPicture.asset(
                          itemData["asset"]!,
                          width: 50,
                          height: 50,
                          color: const Color(0xFFFFFFFF),
                        ),
                        const SizedBox(height: 10),
                        Text(
                          itemData["name"]!,
                          style: const TextStyle(
                              color: Color(0xFFFFFFFF),
                              fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
            const Card(
              color: Color(0xFF5572A9),
              child: Padding(
                padding: EdgeInsets.all(4),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text("About Us",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 32,
                            color: Color(0xFFFFFFFF))),
                    Text(
                      "Makes it easier for users to reserve sports fields, such as football, basketball, badminton, tennis and others. The main features of these applications usually include:",
                      style: TextStyle(color: Color(0xFFFFFFFF)),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "1. Field Search: Users can search for sports fields based on location, type of sport and desired date.",
                      style: TextStyle(color: Color(0xFFFFFFFF)),
                    ),
                    SizedBox(height: 5),
                    Text(
                      "2. Field Details: Provides detailed information about the field, such as size, floor type, supporting facilities (eg changing rooms, parking), as well as photos of the field.",
                      style: TextStyle(color: Color(0xFFFFFFFF)),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
