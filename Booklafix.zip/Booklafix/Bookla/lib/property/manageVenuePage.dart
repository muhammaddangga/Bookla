import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class KelolaVenueArguments {
  final String userId;

  KelolaVenueArguments(this.userId);
}

class KelolaVenuePage extends StatefulWidget {
  const KelolaVenuePage({super.key});

  @override
  KelolaVenuePageState createState() => KelolaVenuePageState();
}

class KelolaVenuePageState extends State<KelolaVenuePage> {
  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as KelolaVenueArguments;
    final result = dbRef
        .collection("venues")
        .where("user_id", isEqualTo: args.userId)
        .get();
    return Scaffold(
        appBar: AppBar(title: const Text('Manage Venue')),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: FutureBuilder(
            future: result,
            builder: (_, snapshot) {
              if (snapshot.hasError) return Text('Error = ${snapshot.error}');
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Text("Loading");
              }
              return ListView(
                  children:
                      snapshot.data!.docs.map((DocumentSnapshot document) {
                Map<String, dynamic> data =
                    document.data()! as Map<String, dynamic>;
                return GestureDetector(
                    onTap: () => Navigator.pushNamed(context, '/editVenue',
                        arguments: {...data, "id": document.id}),
                    child: Container(
                        margin: const EdgeInsets.only(bottom: 20.0),
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          color: const Color(0xFF5572A9),
                        ),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: SizedBox.fromSize(
                                size: const Size.fromRadius(40),
                                child: Image.network(data["gambar"],
                                    fit: BoxFit.cover),
                              ),
                            ),
                            Container(
                              margin: const EdgeInsets.only(left: 20),
                              child: Column(
                                children: [
                                  Text(
                                    data["nama"],
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        color: Color(0xFFFFFFFF)),
                                  ),
                                  Container(
                                    margin: const EdgeInsets.only(top: 10),
                                    child: Text(
                                      data["alamat"],
                                      style: const TextStyle(
                                          color: Color(0xFFFFFFFF)),
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        )));
              }).toList());
            },
          ),
        ));
  }
}
