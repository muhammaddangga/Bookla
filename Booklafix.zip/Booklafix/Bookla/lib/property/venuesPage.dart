import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class VenuesPage extends StatefulWidget {
  const VenuesPage({super.key});

  @override
  VenuesPageState createState() => VenuesPageState();
}

class VenuesPageState extends State<VenuesPage> {
  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;

    final result = dbRef
        .collection("venues")
        .where("jenis", isEqualTo: args["jenis"])
        .get();
    return Scaffold(
        appBar: AppBar(
            title: Text(
          args["nama"],
          style: const TextStyle(fontWeight: FontWeight.bold),
        )),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: FutureBuilder(
            future: result,
            builder: (_, snapshot) {
              if (snapshot.hasError) return Text('Error = ${snapshot.error}');
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Text("Loading");
              }
              return ListView(
                  children:
                      snapshot.data!.docs.map((DocumentSnapshot document) {
                Map<String, dynamic> docData =
                    document.data() as Map<String, dynamic>;
                int sum = 0;
                // ignore: unused_local_variable
                for (int num in docData["rating"]) {
                  sum += num;
                }
                Map<String, dynamic> data = {
                  "id": document.id,
                  "avgRating": sum / docData["rating"].length,
                  ...docData
                };
                return GestureDetector(
                    onTap: () =>
                        Navigator.pushNamed(context, '/venue', arguments: data),
                    child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(10.0),
                          color: const Color(0xFF5572A9),
                        ),
                        margin: const EdgeInsets.only(bottom: 20.0),
                        child: Row(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(20),
                              child: SizedBox.fromSize(
                                size: const Size.fromRadius(40),
                                child: Image.network(data["gambar"],
                                    fit: BoxFit.cover),
                              ),
                            ),
                            const SizedBox(
                              width: 15,
                            ),
                            Expanded(
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Flexible(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          data["nama"],
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            color: Color(0xFFFFFFFF),
                                          ),
                                        ),
                                        const SizedBox(height: 10),
                                        Text(
                                          data["alamat"],
                                          style: const TextStyle(
                                              color: Color(0xFFFFFFFF)),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Row(
                                    children: [
                                      const Icon(
                                        Icons.star,
                                        color: Color.fromARGB(255, 255, 217, 0),
                                      ),
                                      Text(
                                        !data["avgRating"].isNaN
                                            ? data["avgRating"]
                                                .toStringAsFixed(1)
                                            : "0",
                                        style: const TextStyle(
                                            color: Color(0xFFFFFFFF)),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            )
                          ],
                        )));
              }).toList());
            },
          ),
        ));
  }
}
