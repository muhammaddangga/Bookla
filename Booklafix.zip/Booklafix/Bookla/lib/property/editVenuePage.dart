import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:io';

final storage = FirebaseStorage.instance;
final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class EditVenuePage extends StatefulWidget {
  const EditVenuePage({super.key});

  @override
  EditVenuePageState createState() => EditVenuePageState();
}

class EditVenuePageState extends State<EditVenuePage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _description = TextEditingController();
  final TextEditingController _alamatVenue = TextEditingController();
  final TextEditingController _hargaVenue = TextEditingController();
  TimeOfDay jamBuka = TimeOfDay.now();
  TimeOfDay jamTutup = TimeOfDay.now();
  final _listFasilitas = [];
  final TextEditingController _tempFasilitas = TextEditingController();
  String? _typeVenue;
  File? _gambar;
  String gambarPrev = "";
  String docId = "";

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    setState(() {
      _name.text = args["nama"];
      _description.text = args["deskripsi"];
      _alamatVenue.text = args["alamat"];
      jamBuka = TimeOfDay(
          hour: int.parse(args["jamBuka"].split(":")[0]),
          minute: int.parse(args["jamBuka"].split(":")[1]));
      jamTutup = TimeOfDay(
          hour: int.parse(args["jamTutup"].split(":")[0]),
          minute: int.parse(args["jamTutup"].split(":")[1]));
      _typeVenue = args["jenis"];
      args["fasilitas"].forEach((e) => _listFasilitas.add(e));
      gambarPrev = args["gambar"];
      _hargaVenue.text = args["harga"].toString();
      docId = args["id"];
    });
    return Scaffold(
      appBar: AppBar(title: const Text('Edit Venue')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              decoration: const InputDecoration(labelText: 'Venue Name'),
              controller: _name,
            ),
            DropdownButton(
                hint: const Text("Venue Category"),
                value: _typeVenue,
                items: const [
                  DropdownMenuItem(value: "soccer", child: Text("Soccer")),
                  DropdownMenuItem(value: "basket", child: Text("Basket")),
                  DropdownMenuItem(value: "volley", child: Text("Volley")),
                  DropdownMenuItem(
                      value: "badminton", child: Text("Badminton")),
                  DropdownMenuItem(value: "futsal", child: Text("Futsal")),
                ],
                onChanged: (value) {
                  setState(() {
                    _typeVenue = value!;
                  });
                }),
            TextField(
              decoration: const InputDecoration(labelText: 'Venue Address'),
              controller: _alamatVenue,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20.0),
                      child: Text(
                        "${jamBuka.hour}:${jamBuka.minute}",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 5.0),
                      child: ElevatedButton(
                        onPressed: _pilihJamBuka,
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                const Color(0xFF5572A9))),
                        child: const Text('Open',
                            style: TextStyle(color: Color(0xFFFFFFFF))),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20.0),
                      child: Text(
                        "${jamTutup.hour}:${jamTutup.minute}",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 5.0),
                      child: ElevatedButton(
                        onPressed: _pilihJamTutup,
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                const Color(0xFF5572A9))),
                        child: const Text('Close',
                            style: TextStyle(color: Color(0xFFFFFFFF))),
                      ),
                    ),
                  ],
                )
              ],
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Venue Price'),
              controller: _hargaVenue,
              keyboardType: TextInputType.number,
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Description'),
              controller: _description,
            ),
            _gambar == null
                ? Container(
                    margin: const EdgeInsets.only(top: 20.0),
                    child: Image.network(
                      gambarPrev,
                      width: 300,
                      height: 300,
                    ),
                  )
                : Container(
                    margin: const EdgeInsets.only(top: 20.0),
                    child: Image.file(
                      _gambar ?? File(''),
                      width: 300,
                      height: 300,
                    ),
                  ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _pilihGambar,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text('Choose Image',
                    style: TextStyle(color: Color(0xFFFFFFFF))),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0),
              child: Column(
                children: _listFasilitas
                    .map((e) => Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: GestureDetector(
                          child: Text(e),
                          onTap: () {
                            setState(() {
                              _listFasilitas
                                  .removeWhere((element) => element == e);
                            });
                          },
                        )))
                    .toList(),
              ),
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Facility'),
              controller: _tempFasilitas,
            ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _tambahFasilitas,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text('Add Facility',
                    style: TextStyle(color: Color(0xFFFFFFFF))),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _submitForm,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text('Change Venue',
                    style: TextStyle(color: Color(0xFFFFFFFF))),
              ),
            )
          ],
        ),
      ),
    );
  }

  _pilihJamBuka() async {
    final pickedTime = await showTimePicker(
      context: context,
      initialTime: jamBuka,
    );
    setState(() {
      if (pickedTime != null) {
        jamBuka = pickedTime;
      }
    });
  }

  _pilihJamTutup() async {
    final pickedTime = await showTimePicker(
      context: context,
      initialTime: jamTutup,
    );
    setState(() {
      if (pickedTime != null) {
        jamTutup = pickedTime;
      }
    });
  }

  _tambahFasilitas() {
    setState(() {
      _listFasilitas.add(_tempFasilitas.text);
      _tempFasilitas.text = "";
    });
    print(_listFasilitas);
  }

  _pilihGambar() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      if (pickedFile != null) {
        _gambar = File(pickedFile.path);
      }
    });
  }

  _submitForm() async {
    final ref = _gambar != null
        ? storage.ref().child("images/${_gambar?.path.split('/').last}")
        : null;
    final upload = _gambar != null ? await ref?.putFile(_gambar!) : null;
    final uri = _gambar != null ? await ref?.getDownloadURL() : null;
    try {
      await dbRef.collection("venues").doc(docId).update({
        "nama": _name.text,
        "jenis": _typeVenue,
        "alamat": _alamatVenue.text,
        "jamBuka": "${jamBuka.hour}:${jamBuka.minute}",
        "jamTutup": "${jamTutup.hour}:${jamTutup.minute}",
        "harga": int.parse(_hargaVenue.text),
        "deskripsi": _description.text,
        "gambar": _gambar == null ? gambarPrev : uri,
        "fasilitas": _listFasilitas
      });
      Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString() ?? "An error occurred!")));
    }
  }
}
