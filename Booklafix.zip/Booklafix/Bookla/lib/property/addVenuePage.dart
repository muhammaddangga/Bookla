import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:io';

final storage = FirebaseStorage.instance;
final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class AddVenuePage extends StatefulWidget {
  const AddVenuePage({super.key});

  @override
  AddVenuePageState createState() => AddVenuePageState();
}

class AddVenuePageState extends State<AddVenuePage> {
  final TextEditingController _name = TextEditingController();
  final TextEditingController _description = TextEditingController();
  final TextEditingController _alamatVenue = TextEditingController();
  final TextEditingController _hargaVenue = TextEditingController();
  TimeOfDay jamBuka = TimeOfDay.now();
  TimeOfDay jamTutup = TimeOfDay.now();
  List<String> _listFasilitas = [];
  final TextEditingController _tempFasilitas = TextEditingController();
  String? _typeVenue;
  File? _gambar;
  bool isFirst = false;

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    setState(() {
      isFirst = args["isFirst"];
    });
    return Scaffold(
      appBar: AppBar(
        title: const Text('Add Venue'),
        automaticallyImplyLeading: !isFirst,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            TextField(
              decoration: const InputDecoration(labelText: 'Venue Name'),
              controller: _name,
            ),
            DropdownButton(
                hint: const Text("Venue Categories"),
                value: _typeVenue,
                items: const [
                  DropdownMenuItem(value: "soccer", child: Text("Soccer")),
                  DropdownMenuItem(value: "basket", child: Text("Basket")),
                  DropdownMenuItem(value: "volley", child: Text("Volley")),
                  DropdownMenuItem(
                      value: "badminton", child: Text("Badminton")),
                  DropdownMenuItem(value: "futsal", child: Text("Futsal")),
                ],
                onChanged: (value) {
                  setState(() {
                    _typeVenue = value!;
                  });
                }),
            TextField(
              decoration: const InputDecoration(labelText: 'Venue Address'),
              controller: _alamatVenue,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20.0),
                      child: Text(
                        "${jamBuka.hour}:${jamBuka.minute}",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 5.0),
                      child: ElevatedButton(
                        onPressed: _pilihJamBuka,
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                const Color(0xFF5572A9))),
                        child: const Text('Open',
                            style: TextStyle(color: Color(0xFFFFFFFF))),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.only(top: 20.0),
                      child: Text(
                        "${jamTutup.hour}:${jamTutup.minute}",
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                    Container(
                      margin: const EdgeInsets.only(top: 5.0),
                      child: ElevatedButton(
                        onPressed: _pilihJamTutup,
                        style: ButtonStyle(
                            backgroundColor: MaterialStateProperty.all<Color>(
                                const Color(0xFF5572A9))),
                        child: const Text('Close',
                            style: TextStyle(color: Color(0xFFFFFFFF))),
                      ),
                    ),
                  ],
                )
              ],
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Venue Price'),
              controller: _hargaVenue,
              keyboardType: TextInputType.number,
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Description'),
              controller: _description,
            ),
            _gambar == null
                ? Container()
                : Container(
                    margin: const EdgeInsets.only(top: 20.0),
                    child: Image.file(
                      _gambar ?? File(''),
                      width: 300,
                      height: 300,
                    ),
                  ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _pilihGambar,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text('Choose Image',
                    style: TextStyle(color: Color(0xFFFFFFFF))),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 10.0),
              child: Column(
                children: _listFasilitas
                    .map((e) => Padding(
                        padding: const EdgeInsets.only(top: 10.0),
                        child: GestureDetector(
                          child: Text(e),
                          onTap: () {
                            setState(() {
                              _listFasilitas
                                  .removeWhere((element) => element == e);
                            });
                          },
                        )))
                    .toList(),
              ),
            ),
            TextField(
              decoration: const InputDecoration(labelText: 'Facility'),
              controller: _tempFasilitas,
            ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _tambahFasilitas,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text('Add Facility',
                    style: TextStyle(color: Color(0xFFFFFFFF))),
              ),
            ),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _submitForm,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text('Add Venue',
                    style: TextStyle(color: Color(0xFFFFFFFF))),
              ),
            )
          ],
        ),
      ),
    );
  }

  _pilihJamBuka() async {
    final pickedTime = await showTimePicker(
      context: context,
      initialTime: jamBuka,
    );
    setState(() {
      if (pickedTime != null) {
        jamBuka = pickedTime;
      }
    });
  }

  _pilihJamTutup() async {
    final pickedTime = await showTimePicker(
      context: context,
      initialTime: jamTutup,
    );
    setState(() {
      if (pickedTime != null) {
        jamTutup = pickedTime;
      }
    });
  }

  _tambahFasilitas() {
    setState(() {
      _listFasilitas.add(_tempFasilitas.text);
      _tempFasilitas.text = "";
    });
  }

  _pilihGambar() async {
    final pickedFile =
        await ImagePicker().pickImage(source: ImageSource.gallery);
    setState(() {
      if (pickedFile != null) {
        _gambar = File(pickedFile.path);
      }
    });
  }

  _submitForm() async {
    if (_gambar == null) {
      return ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("The image cannot be empty")));
    }
    final ref = storage.ref().child("images/${_gambar?.path.split('/').last}");
    final upload = await ref.putFile(_gambar!);
    final uri = await ref.getDownloadURL();
    try {
      if (isFirst) {
        await dbRef
            .collection("users")
            .where("uid", isEqualTo: _auth.currentUser!.uid)
            .get()
            .then((value) async => await dbRef
                .collection("users")
                .doc(value.docs[0].id)
                .update({"isFirst": false}));
      }
      await dbRef.collection("venues").add({
        "user_id": _auth.currentUser!.uid,
        "nama": _name.text,
        "jenis": _typeVenue,
        "alamat": _alamatVenue.text,
        "jamBuka": "${jamBuka.hour}:${jamBuka.minute}",
        "jamTutup": "${jamTutup.hour}:${jamTutup.minute}",
        "harga": int.parse(_hargaVenue.text),
        "deskripsi": _description.text,
        "gambar": uri,
        "fasilitas": _listFasilitas,
        "rating": []
      });
      Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString() ?? "An error occurred!")));
    }
  }
}
