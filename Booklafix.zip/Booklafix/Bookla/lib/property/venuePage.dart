import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_datetime_picker_plus/flutter_datetime_picker_plus.dart';
import 'package:flutter_searchable_dropdown/flutter_searchable_dropdown.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:geocoding/geocoding.dart';
import 'package:map_launcher/map_launcher.dart';
import 'package:intl/intl.dart';

final storage = FirebaseStorage.instance;
final dbRef = FirebaseFirestore.instance;
final _auth = FirebaseAuth.instance;

class BookingDataSource extends CalendarDataSource {
  BookingDataSource(List<Booking> source) {
    appointments = source;
  }

  @override
  DateTime getStartTime(int index) {
    return _getBookingData(index).from;
  }

  @override
  DateTime getEndTime(int index) {
    return _getBookingData(index).to;
  }

  @override
  String getSubject(int index) {
    return _getBookingData(index).eventName;
  }

  @override
  Color getColor(int index) {
    return _getBookingData(index).background;
  }

  @override
  bool isAllDay(int index) {
    return _getBookingData(index).isAllDay;
  }

  Booking _getBookingData(int index) {
    final dynamic booking = appointments![index];
    late final Booking BookingData;
    if (booking is Booking) {
      BookingData = booking;
    }

    return BookingData;
  }
}

class Booking {
  Booking(this.from, this.to);
  String eventName = "";
  DateTime from;
  DateTime to;
  Color background = const Color.fromARGB(255, 255, 0, 0);
  bool isAllDay = false;
}

class VenuePage extends StatefulWidget {
  const VenuePage({super.key});

  @override
  VenuePageState createState() => VenuePageState();
}

class VenuePageState extends State<VenuePage> {
  Map<String, dynamic>? data;
  final fasilitas = [];
  String fotografer = "";
  List<dynamic> listFotografer = [];
  DateTime waktuMulai = DateTime.now();
  DateTime waktuBerakhir = DateTime.now();
  final TextEditingController _voucher = TextEditingController();
  List<Booking> listBooking = [];
  bool isUpdated = false;

  @override
  void initState() {
    dbRef.collection("fotografer").get().then((snapshot) {
      setState(() {
        listFotografer =
            snapshot.docs.map((e) => {"id": e.id, ...e.data()}).toList();
      });
    });
    FirebaseFirestore.instance.collection('booking').get().then((value) {
      List<Booking> tempList = [];
      for (dynamic snapshot in value.docs) {
        final dataBooking = snapshot.data();

        if (dataBooking.containsKey("venue") &&
            dataBooking["venue"].id == data?["id"]) {
          tempList.add(Booking(dataBooking["waktuMulai"].toDate(),
              dataBooking["waktuBerakhir"].toDate()));
        }
      }
      setState(() {
        listBooking = tempList;
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final args =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    if (!isUpdated) {
      setState(() {
        data = args;
        args["fasilitas"].forEach((e) => fasilitas.add(e));
        isUpdated = true;
      });
    }
    return Scaffold(
      appBar: AppBar(title: Text('Field ${data?["nama"]}')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView(
          children: [
            ClipRRect(
                borderRadius: BorderRadius.circular(20),
                child: SizedBox.fromSize(
                  child: Image.network(data?["gambar"], fit: BoxFit.cover),
                )),
            const SizedBox(height: 10),
            Text(
              data?["nama"],
              style:
                  const TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
            ),
            const SizedBox(height: 5),
            GestureDetector(
                onTap: () async {
                  final location =
                      (await locationFromAddress(data?["alamat"]))[0];
                  final availableMaps = await MapLauncher.installedMaps;
                  await availableMaps.first.showMarker(
                    coords: Coords(location.latitude, location.longitude),
                    title: data?["nama"],
                  );
                },
                child: Text(data?["alamat"])),
            const SizedBox(height: 15),
            const Text(
              "Facility",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
            ),
            const SizedBox(height: 5),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                  children: fasilitas
                      .map((text) => Container(
                            margin: const EdgeInsets.only(right: 10.0),
                            decoration:
                                BoxDecoration(border: Border.all(width: 1.0)),
                            child: Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: Text(text)),
                          ))
                      .toList()),
            ),
            const SizedBox(height: 15),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Column(
                  children: [
                    const Text("Open"),
                    Container(
                      margin: const EdgeInsets.only(top: 5.0),
                      child: Text(
                        args["jamBuka"],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    const Text("Close"),
                    Container(
                      margin: const EdgeInsets.only(top: 5.0),
                      child: Text(
                        args["jamTutup"],
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    ),
                  ],
                )
              ],
            ),
            const SizedBox(height: 15),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              Column(children: [
                Container(
                  margin: const EdgeInsets.only(top: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      DatePicker.showDateTimePicker(
                        context,
                        minTime: DateTime(
                            DateTime.now().year,
                            DateTime.now().month,
                            DateTime.now().day,
                            DateTime.now().hour,
                            DateTime.now().minute),
                        maxTime: DateTime(
                            DateTime.now().year,
                            DateTime.now().month,
                            DateTime.now().day + 7,
                            int.parse(args["jamTutup"].split(":")[0]),
                            int.parse(args["jamTutup"].split(":")[0])),
                        currentTime: waktuMulai,
                        onConfirm: (time) {
                          setState(() {
                            waktuMulai = time;
                          });
                        },
                      );
                    },
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            const Color(0xFF5572A9))),
                    child: const Text(
                      'Choose Start Time',
                      style: TextStyle(color: Color(0xFFFFFFFF)),
                    ),
                  ),
                ),
                Text(
                  DateFormat('HH:mm').format(waktuMulai).toString(),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                )
              ]),
              Column(children: [
                Container(
                  margin: const EdgeInsets.only(top: 5.0),
                  child: ElevatedButton(
                    onPressed: () {
                      DatePicker.showDateTimePicker(
                        context,
                        minTime: DateTime(
                            DateTime.now().year,
                            DateTime.now().month,
                            DateTime.now().day,
                            DateTime.now().hour,
                            DateTime.now().minute),
                        maxTime: DateTime(
                            DateTime.now().year,
                            DateTime.now().month,
                            DateTime.now().day + 7,
                            int.parse(args["jamTutup"].split(":")[0]),
                            int.parse(args["jamTutup"].split(":")[0])),
                        currentTime: waktuBerakhir,
                        onConfirm: (time) {
                          setState(() {
                            waktuBerakhir = time;
                          });
                        },
                      );
                    },
                    style: ButtonStyle(
                        backgroundColor: MaterialStateProperty.all<Color>(
                            const Color(0xFF5572A9))),
                    child: const Text(
                      'Choose End Time',
                      style: TextStyle(color: Color(0xFFFFFFFF)),
                    ),
                  ),
                ),
                Text(
                  DateFormat('HH:mm').format(waktuBerakhir).toString(),
                  style: const TextStyle(fontWeight: FontWeight.bold),
                )
              ])
            ]),
            const SizedBox(height: 15),
            SfCalendar(
              view: CalendarView.week,
              dataSource: BookingDataSource(listBooking),
            ),
            const SizedBox(height: 15),
            const Text(
              "Fotografer",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0),
            ),
            const SizedBox(height: 5),
            SearchableDropdown.single(
              items: listFotografer
                  .map((e) =>
                      DropdownMenuItem(value: e["id"], child: Text(e["name"])))
                  .toList(),
              value: fotografer,
              hint: "Choose Fotografer (Optional)",
              searchHint: "Choose Fotografer (Optional)",
              displayClearIcon: false,
              onChanged: (value) {
                setState(() {
                  fotografer = value;
                });
              },
              isExpanded: true,
            ),
            // const SizedBox(height: 15),
            TextField(
              decoration:
                  const InputDecoration(labelText: 'Voucher (Optional)'),
              controller: _voucher,
            ),
            Container(
                decoration: const BoxDecoration(
                    border: Border(bottom: BorderSide(width: 2.0))),
                child: Text(
                  fotografer == ""
                      ? "Total Price : Rp ${waktuBerakhir.difference(waktuMulai).inHours * args["harga"]}"
                      : "Total Price : Rp ${waktuBerakhir.difference(waktuMulai).inHours * (args["harga"] + 200000)}",
                  style: const TextStyle(
                      fontSize: 20.0, fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                )),
            Container(
              margin: const EdgeInsets.only(top: 20.0),
              child: ElevatedButton(
                onPressed: _book,
                style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all<Color>(
                        const Color(0xFF5572A9))),
                child: const Text(
                  'Book Now',
                  style: TextStyle(color: Color(0xFFFFFFFF)),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  bool _check(DateTime firstFrom, DateTime firstTo, DateTime secondFrom,
      DateTime secondTo) {
    // Check if secondFrom is after or equal to firstFrom
    // and if secondTo is before or equal to firstTo
    return (secondFrom.isAfter(firstFrom) ||
            secondFrom.isAtSameMomentAs(firstFrom)) &&
        (secondTo.isBefore(firstTo) || secondTo.isAtSameMomentAs(firstTo));
  }

  _book() async {
    final user = await dbRef
        .collection("users")
        .where("uid", isEqualTo: _auth.currentUser!.uid)
        .get();
    final userData = user.docs[0].data();
    if (userData["role"] != "user") {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Selain user tidak bisa booking !!")));
      return;
    }
    for (Booking perbandingan in listBooking) {
      if (_check(
          perbandingan.from, perbandingan.to, waktuMulai, waktuBerakhir)) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text("Lapangan Sudah ditempati")));
        return;
      }
    }
    try {
      await dbRef.collection("booking").add({
        "type": "venue",
        "waktuMulai": waktuMulai,
        "waktuBerakhir": waktuBerakhir,
        "venue": dbRef.collection("venues").doc(data?["id"]),
        "user_id": _auth.currentUser!.uid,
        "isRated": false
      });
      if (fotografer != "") {
        await dbRef.collection("booking").add({
          "type": "fotografer",
          "waktuMulai": waktuMulai,
          "waktuBerakhir": waktuBerakhir,
          "fotografer": dbRef.collection("fotografer").doc(fotografer),
          "user_id": _auth.currentUser!.uid,
          "isRated": false
        });
      }
      Navigator.pushReplacementNamed(context, '/home');
    } on FirebaseException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString() ?? "An error occurred!")));
    }
  }
}
